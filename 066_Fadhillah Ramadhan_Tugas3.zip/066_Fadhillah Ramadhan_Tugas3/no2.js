const cek=()=>{
          
    if (form.angka1.value == "" || form.angka2.value == "") {
 
     alert("Angka Kosong");
 
     exit
 
    }
 
   }
 
   const tambah=()=>{
 
    cek();
 
    a = parseInt(form.angka1.value);
 
    b = parseInt(form.angka2.value);
 
    form.hasil.value = a+b;
 
   }
 
   const kurang=()=>{
 
    cek();
 
    a = parseInt(form.angka1.value);
 
    b = parseInt(form.angka2.value);
 
    form.hasil.value = a-b;
 
   }
 
   const kali=()=>{
 
    cek();
 
    a = parseInt(form.angka1.value);
 
    b = parseInt(form.angka2.value);
 
    form.hasil.value = a*b;
 
   }
 
   const bagi=()=>{
 
    cek();
 
    a = parseInt(form.angka1.value);
 
    b = parseInt(form.angka2.value);
 
    form.hasil.value = a/b;
 
   }

   const modulus=()=>{
 
       cek();
    
       a = parseInt(form.angka1.value);
    
       b = parseInt(form.angka2.value);
    
       form.hasil.value = a%b;
    
      }
 
 